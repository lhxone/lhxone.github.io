#!/bin/bash
#SBATCH -J vasp_job
#SBATCH -o vasp_on_slurm_%j.log
#SBATCH -e vasp_on_slurm_error_%j.log
echo Running on hosts
echo Time is `date`
echo Directory is $PWD
echo This job runs on the following nodes:
echo $SLURM_JOB_NODELIST
echo Starting
vasp_std
