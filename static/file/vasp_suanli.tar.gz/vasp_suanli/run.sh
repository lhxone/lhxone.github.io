#!/bin/bash
csub -I -J vasp_test -q g1group -n 16 -R span[ptile=8] -m "n00004 n00005" -o my_test_28.log impi-mpirun vasp_std
