#!/bin/bash

#SBATCH --partition=test

spack load vasp@6.1.0

mpirun vasp_std
